module.exports = {
    PLAID_CLIENT_ID: '6704fbff6bb863001ae2c13a',
    PLAID_SECRET: 'aadbb5abd53dcdab0e52275771cf53'
};